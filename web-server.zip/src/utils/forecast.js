const request = require("postman-request")

const forecast = (latitude, longitude, callback) => {
  const url =
    "http://api.weatherstack.com/current?access_key=85e5259c6f7f6a67e0cd9898311e97e9&query=" +
    latitude +
    "," +
    longitude +
    "&units=f"

  request({ url, json: true }, (error, { body } = {}) => {
    //console.log(response.body.current)
    if (error) {
      callback("Unable to connect to weather server:" + error.errno, undefined)
    } else if (body.error) {
      //callback("Please check the location")
      callback(body.error.info, undefined)
    } else {
      callback(
        undefined,
        "Description: " +
          body.current.weather_descriptions[0] +
          ", Tempreature: " +
          body.current.temperature +
          ", FeelsLike: " +
          body.current.feelslike
      )
    }
  })
}

module.exports = forecast
